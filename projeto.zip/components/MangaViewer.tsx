
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { ProcessedImage, ViewMode, TextBubble } from '../types';
import BubbleOverlay from './BubbleOverlay';
import { 
  MagnifyingGlassPlusIcon, 
  MagnifyingGlassMinusIcon,
  EyeIcon,
  EyeSlashIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  PencilSquareIcon,
  XMarkIcon,
  CheckIcon,
  TrashIcon,
  PaintBrushIcon,
  SparklesIcon,
  SquaresPlusIcon,
  StopIcon,
  CubeTransparentIcon,
  ArrowsPointingOutIcon,
  SunIcon,
  Bars3BottomLeftIcon,
  Bars3Icon,
  Bars3BottomRightIcon,
  ArrowsPointingInIcon,
  AdjustmentsVerticalIcon,
  ArrowDownTrayIcon
} from '@heroicons/react/24/outline';

interface MangaViewerProps {
  image: ProcessedImage;
  onNext?: () => void;
  onPrev?: () => void;
  onBubbleUpdate?: (bubble: TextBubble) => void;
  onBubbleDelete?: (bubbleId: string) => void;
  onImageUpdate?: (image: ProcessedImage) => void;
  onToggleStrip?: () => void;
  stripMode?: boolean;
  isCleanMode?: boolean;
  defaultFont?: string;
  globalBold?: boolean;
  globalItalic?: boolean;
  globalBubbleScale?: number;
  customFonts?: FontOption[];
}

export type FontOption = { name: string; value: string; type?: 'font' };
export type FontGroup = { group: string; options: FontOption[]; type: 'group' };

export const AVAILABLE_FONTS: (FontOption | FontGroup)[] = [
  { name: 'CC Wild Words (BR)', value: '"CC Wild Words Roman BR", "CC Wild Words", "Comic Sans MS", sans-serif' },
  {
    group: 'Clássicos do Mangá',
    type: 'group',
    options: [
      { name: 'Anime Ace', value: '"Anime Ace", sans-serif' },
      { name: 'Anime Ace 2.0 BB', value: '"Anime Ace 2.0 BB", sans-serif' },
      { name: 'Manga Temple', value: '"Manga Temple", sans-serif' },
      { name: 'Komika Axis', value: '"Komika Axis", sans-serif' },
    ]
  },
  {
    group: 'Diálogos Manga',
    type: 'group',
    options: [
        { name: 'Comic Neue', value: '"Comic Neue", "Comic Sans MS", sans-serif' },
        { name: 'Kalam', value: '"Kalam", "Coming Soon", cursive' },
        { name: 'Architects Daughter', value: '"Architects Daughter", cursive' },
    ]
  },
  {
    group: 'SFX & Pincel',
    type: 'group',
    options: [
        { name: 'Permanent Marker', value: '"Permanent Marker", display' },
        { name: 'Bangers', value: '"Bangers", display' },
    ]
  },
  { name: 'Comic (Padrão)', value: '"Comic Sans MS", sans-serif' },
];

export const DEFAULT_FONT_VALUE = (AVAILABLE_FONTS[0] as FontOption).value;

const MangaViewer: React.FC<MangaViewerProps> = ({ 
  image, 
  onNext, 
  onPrev,
  onBubbleUpdate,
  onBubbleDelete,
  onImageUpdate,
  onToggleStrip,
  stripMode = false,
  isCleanMode = false,
  defaultFont,
  globalBold = true,
  globalItalic = false,
  globalBubbleScale = 1.0,
  customFonts = []
}) => {
  const [zoom, setZoom] = useState(1);
  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.TRANSLATED);
  const [isEditingMode, setIsEditingMode] = useState(false);
  
  const [hideBubbleBorders, setHideBubbleBorders] = useState(true);
  const [isBubbleTransparent, setIsBubbleTransparent] = useState(false);
  const [showTextStroke, setShowTextStroke] = useState(true);
  
  const [isPaintMode, setIsPaintMode] = useState(false);
  const [brushSize, setBrushSize] = useState(20);
  const [paintColor, setPaintColor] = useState('#FFFFFF');
  
  // Inline Edit State
  const [editingBubbleId, setEditingBubbleId] = useState<string | null>(null);
  const [showAdvancedToolbar, setShowAdvancedToolbar] = useState(false);
  const [calculatedFontSizes, setCalculatedFontSizes] = useState<Record<string, number>>({});

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const isDrawing = useRef(false);

  const isFullServerResult = !!image.translatedImageUrl && image.bubbles.length === 0;
  const hasOverlays = image.bubbles.length > 0;
  const activeImageUrl = (viewMode === ViewMode.TRANSLATED && image.translatedImageUrl) ? image.translatedImageUrl : image.imageUrl;

  const allFonts = useMemo(() => {
    if (customFonts.length === 0) return AVAILABLE_FONTS;
    return [...customFonts, ...AVAILABLE_FONTS];
  }, [customFonts]);

  const activeBubble = useMemo(() => 
    image.bubbles.find(b => b.id === editingBubbleId), 
  [image.bubbles, editingBubbleId]);

  useEffect(() => {
    setZoom(1);
    setIsEditingMode(false); 
    setIsPaintMode(false);
    setEditingBubbleId(null);
  }, [image.id]);

  useEffect(() => {
    if (isFullServerResult || stripMode) return; 
    const canvas = canvasRef.current;
    const img = imgRef.current;
    
    if (canvas && img && image.status === 'done') {
      const initCanvas = () => {
        if (canvas.width !== img.naturalWidth || canvas.height !== img.naturalHeight) {
             canvas.width = img.naturalWidth;
             canvas.height = img.naturalHeight;
        }
        const ctx = canvas.getContext('2d');
        if (ctx) {
          if (image.maskDataUrl) {
            const maskImg = new Image();
            maskImg.onload = () => {
              ctx.clearRect(0, 0, canvas.width, canvas.height);
              ctx.drawImage(maskImg, 0, 0);
            };
            maskImg.src = image.maskDataUrl;
          } else {
             ctx.clearRect(0, 0, canvas.width, canvas.height);
          }
        }
      };
      if (img.complete) initCanvas();
      else img.onload = initCanvas;
    }
  }, [image.id, image.status, image.maskDataUrl, isFullServerResult, stripMode]);

  const startEditingBubble = (bubble: TextBubble | null) => {
    setEditingBubbleId(bubble ? bubble.id : null);
  };

  const getCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return { x: (e.clientX - rect.left) * scaleX, y: (e.clientY - rect.top) * scaleY };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPaintMode) return;
    isDrawing.current = true;
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) {
       const { x, y } = getCoords(e);
       ctx.beginPath(); ctx.moveTo(x, y); ctx.strokeStyle = paintColor; ctx.lineWidth = brushSize; ctx.lineCap = 'round'; ctx.lineTo(x, y); ctx.stroke();
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPaintMode || !isDrawing.current) return;
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) { const { x, y } = getCoords(e); ctx.lineTo(x, y); ctx.stroke(); }
  };

  const stopDrawing = () => {
    if (!isDrawing.current) return;
    isDrawing.current = false;
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) {
      ctx.closePath();
      if (canvasRef.current && onImageUpdate) onImageUpdate({ ...image, maskDataUrl: canvasRef.current.toDataURL() });
    }
  };

  const handleDownload = async () => {
    if (!imgRef.current) return;
    const img = imgRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 1. Desenhar imagem base
    ctx.drawImage(img, 0, 0);

    // 2. Desenhar limpeza (mask) se houver
    if (canvasRef.current) {
      ctx.drawImage(canvasRef.current, 0, 0);
    }

    // 3. Desenhar balões (Simplificado para canvas)
    for (const bubble of image.bubbles) {
      const width = (bubble.box.xmax - bubble.box.xmin) / 1000 * canvas.width;
      const height = (bubble.box.ymax - bubble.box.ymin) / 1000 * canvas.height;
      const x = bubble.box.xmin / 1000 * canvas.width;
      const y = bubble.box.ymin / 1000 * canvas.height;

      const bubbleScale = bubble.scale ?? globalBubbleScale;
      const sWidth = width * bubbleScale;
      const sHeight = height * bubbleScale;
      const sx = x + (width - sWidth) / 2;
      const sy = y + (height - sHeight) / 2;

      if (!isBubbleTransparent && bubble.type !== 'sfx') {
        ctx.fillStyle = 'white';
        ctx.beginPath();
        ctx.roundRect(sx, sy, sWidth, sHeight, 10);
        ctx.fill();
      }

      const fontSize = bubble.fontSize || calculatedFontSizes[bubble.id] || 14;
      const font = bubble.fontFamily || defaultFont || 'sans-serif';
      const weight = bubble.fontWeight || (globalBold ? 'bold' : 'normal');
      const style = bubble.fontStyle || (globalItalic ? 'italic' : 'normal');

      ctx.font = `${style} ${weight} ${fontSize}px ${font}`;
      ctx.fillStyle = 'black';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Quebra de linha básica
      const words = bubble.translatedText.split(' ');
      const lines = [];
      let currentLine = '';
      for (const word of words) {
        const testLine = currentLine + word + ' ';
        if (ctx.measureText(testLine).width > sWidth * 0.9 && currentLine !== '') {
          lines.push(currentLine);
          currentLine = word + ' ';
        } else {
          currentLine = testLine;
        }
      }
      lines.push(currentLine);

      const lineHeight = fontSize * 1.2;
      const totalTextHeight = lines.length * lineHeight;
      let startY = sy + (sHeight - totalTextHeight) / 2 + lineHeight / 2;

      lines.forEach((line) => {
        ctx.fillText(line.trim(), sx + sWidth / 2, startY);
        startY += lineHeight;
      });
    }

    const link = document.createElement('a');
    link.download = `traducao_${image.fileName}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className={`flex flex-col h-full ${stripMode ? '' : 'bg-slate-900 rounded-lg border border-slate-700 shadow-2xl overflow-hidden'} relative`}>
      
      {!stripMode && !isCleanMode && (
        <div className="h-14 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-3 md:px-4 sticky top-0 z-50">
          <div className="flex items-center space-x-2">
             <button onClick={onPrev} disabled={!onPrev} className={`p-1.5 rounded-lg transition-colors ${onPrev ? 'text-white hover:bg-slate-700' : 'text-slate-600'}`}>
               <ChevronLeftIcon className="w-5 h-5" />
             </button>
             <button onClick={onNext} disabled={!onNext} className={`p-1.5 rounded-lg transition-colors ${onNext ? 'text-white hover:bg-slate-700' : 'text-slate-600'}`}>
               <ChevronRightIcon className="w-5 h-5" />
             </button>
             <div className="h-6 w-px bg-slate-600 mx-1 hidden sm:block"></div>
             <span className={`text-[10px] sm:text-xs font-mono px-2 py-0.5 rounded ${image.status === 'done' ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                {image.status === 'done' ? (isFullServerResult ? 'IMG' : 'OCR') : '...'}
             </span>
          </div>

          <div className="flex items-center gap-1 md:gap-2">
            {image.status === 'done' && hasOverlays && (
              <>
                <button onClick={handleDownload} className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg" title="Baixar Página Traduzida">
                  <ArrowDownTrayIcon className="w-5 h-5" />
                </button>
                <div className="h-6 w-px bg-slate-700 mx-1"></div>
                <button onClick={() => { setIsPaintMode(!isPaintMode); setIsEditingMode(false); }} className={`p-2 rounded-lg ${isPaintMode ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`} title="Pintar (Whiteout)">
                  <PaintBrushIcon className="w-5 h-5" />
                </button>
                <button onClick={() => { setIsEditingMode(!isEditingMode); setIsPaintMode(false); }} className={`p-2 rounded-lg ${isEditingMode ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`} title="Manipulação Direta">
                  <PencilSquareIcon className="w-5 h-5" />
                </button>
                
                <div className="flex items-center gap-1 bg-slate-900/50 p-1 rounded-lg border border-slate-700/50">
                  <button onClick={() => setHideBubbleBorders(!hideBubbleBorders)} className={`p-1.5 rounded-md ${hideBubbleBorders ? 'text-indigo-400 bg-slate-800' : 'text-slate-400 hover:text-white'}`} title="Ocultar Bordas">
                    <StopIcon className="w-4 h-4" />
                  </button>
                  <button onClick={() => setIsBubbleTransparent(!isBubbleTransparent)} className={`p-1.5 rounded-md ${isBubbleTransparent ? 'text-indigo-400 bg-slate-800' : 'text-slate-400 hover:text-white'}`} title="Fundo Transparente">
                    <CubeTransparentIcon className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
            
            <div className="h-6 w-px bg-slate-600 mx-1 hidden sm:block"></div>

            <button onClick={() => setViewMode(prev => prev === ViewMode.TRANSLATED ? ViewMode.ORIGINAL : ViewMode.TRANSLATED)} className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg">
               {viewMode === ViewMode.TRANSLATED ? <EyeIcon className="w-5 h-5"/> : <EyeSlashIcon className="w-5 h-5"/>}
            </button>
            
            <div className="flex items-center hidden md:flex">
              <button onClick={() => setZoom(z => Math.max(0.5, z - 0.25))} className="p-2 text-slate-300 hover:bg-slate-700 rounded-lg"><MagnifyingGlassMinusIcon className="w-4 h-4" /></button>
              <button onClick={() => setZoom(z => Math.min(4, z + 0.25))} className="p-2 text-slate-300 hover:bg-slate-700 rounded-lg"><MagnifyingGlassPlusIcon className="w-4 h-4" /></button>
            </div>
          </div>
        </div>
      )}

      <div 
        ref={containerRef}
        onMouseDown={() => setEditingBubbleId(null)}
        className={`flex-1 relative bg-slate-950 ${stripMode ? '' : 'overflow-auto flex justify-center items-start p-4 scrollbar-hide'}`}
      >
        <div 
          className="relative transition-transform duration-200 ease-out origin-top"
          onMouseDown={(e) => e.stopPropagation()}
          style={{ 
            width: stripMode ? '100%' : (image.status === 'done' ? 'auto' : '100%'), 
            maxWidth: stripMode ? '100%' : '1200px',
            transform: stripMode ? 'none' : `scale(${zoom})`,
          }}
        >
          <img 
            ref={imgRef}
            src={activeImageUrl} 
            alt="Manga Page" 
            className="w-full h-auto shadow-2xl select-none"
            style={{ display: 'block' }}
          />

          {image.status === 'done' && !isFullServerResult && !stripMode && (
            <canvas
              ref={canvasRef}
              onMouseDown={startDrawing} onMouseMove={draw} onMouseUp={stopDrawing} onMouseLeave={stopDrawing}
              className={`absolute inset-0 z-10 w-full h-full ${isPaintMode ? 'cursor-crosshair pointer-events-auto' : 'pointer-events-none'}`}
            />
          )}

          {image.status === 'done' && hasOverlays && (
            <div className={`absolute inset-0 w-full h-full z-20 ${isPaintMode ? 'pointer-events-none opacity-40' : ''}`}>
              {image.bubbles.map(bubble => {
                const isVisible = (viewMode === ViewMode.TRANSLATED) || isEditingMode;
                if (!isVisible) return null;

                return (
                  <BubbleOverlay 
                    key={bubble.id} 
                    bubble={bubble} 
                    isEditing={isEditingMode && !stripMode} 
                    activeEditingId={editingBubbleId}
                    hideBorder={hideBubbleBorders}
                    isTransparent={isBubbleTransparent}
                    onUpdate={onBubbleUpdate}
                    onEditStart={startEditingBubble}
                    onDelete={onBubbleDelete}
                    defaultFont={defaultFont}
                    enableTextStroke={showTextStroke}
                    globalBold={globalBold}
                    globalItalic={globalItalic}
                    globalBubbleScale={globalBubbleScale}
                    onFontSizeCalculated={(size) => setCalculatedFontSizes(prev => ({...prev, [bubble.id]: size}))}
                    fontSizeCalculatedValue={calculatedFontSizes[bubble.id]}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Floating Formatting Toolbar (Inline Edit) */}
      {activeBubble && (
        <div 
          className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[70] bg-slate-900 border border-slate-700 p-3 rounded-2xl shadow-2xl flex flex-col gap-3 min-w-[320px] animate-fade-in-up"
          onMouseDown={(e) => e.stopPropagation()} 
          onClick={(e) => e.stopPropagation()}
        >
           <div className="flex items-center justify-between border-b border-slate-800 pb-2">
             <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Fonte Atual</span>
                <span className="bg-indigo-500/20 text-indigo-400 text-[11px] px-2 py-0.5 rounded-md font-mono font-bold shadow-inner">
                   {activeBubble.fontSize || (calculatedFontSizes[activeBubble.id] ? Math.round(calculatedFontSizes[activeBubble.id]) : '--')}px
                </span>
             </div>
             <button onMouseDown={(e) => { e.stopPropagation(); setShowAdvancedToolbar(!showAdvancedToolbar); }} className="text-indigo-400 hover:text-white">
                <AdjustmentsVerticalIcon className="w-5 h-5" />
             </button>
           </div>

           <div className="flex items-center gap-3">
              <select 
                value={activeBubble.fontFamily || defaultFont} 
                onChange={(e) => onBubbleUpdate && onBubbleUpdate({ ...activeBubble, fontFamily: e.target.value })}
                onMouseDown={(e) => e.stopPropagation()}
                className="flex-1 bg-slate-800 border border-slate-700 text-white rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500"
              >
                {allFonts.map((font, idx) => {
                  if ('group' in font) return (
                    <optgroup key={idx} label={font.group}>
                      {font.options.map((opt, subIdx) => (
                        <option key={`${idx}-${subIdx}`} value={opt.value}>{opt.name}</option>
                      ))}
                    </optgroup>
                  );
                  return <option key={idx} value={font.value}>{font.name}</option>;
                })}
              </select>
              
              <div className="w-20 relative">
                 <input 
                    type="number" 
                    value={activeBubble.fontSize || ''} 
                    onChange={(e) => onBubbleUpdate && onBubbleUpdate({ ...activeBubble, fontSize: parseInt(e.target.value) || undefined })}
                    onMouseDown={(e) => e.stopPropagation()}
                    placeholder="Auto"
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg p-1.5 text-xs text-center pr-6"
                 />
                 <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] text-slate-500 pointer-events-none">px</span>
              </div>
           </div>

           {showAdvancedToolbar && (
              <div className="grid grid-cols-2 gap-3 pt-1 animate-fade-in">
                 <div className="space-y-1">
                    <span className="text-[9px] text-slate-500 font-bold uppercase">Alinhamento</span>
                    <div className="flex bg-slate-800 rounded-lg p-1 border border-slate-700">
                      {(['left', 'center', 'right'] as const).map(align => (
                        <button 
                          key={align}
                          onClick={() => onBubbleUpdate && onBubbleUpdate({ ...activeBubble, textAlign: align })}
                          className={`flex-1 p-1 rounded ${activeBubble.textAlign === align ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-700'}`}
                        >
                           {align === 'left' ? <Bars3BottomLeftIcon className="w-3.5 h-3.5 mx-auto"/> : align === 'center' ? <Bars3Icon className="w-3.5 h-3.5 mx-auto"/> : <Bars3BottomRightIcon className="w-3.5 h-3.5 mx-auto"/>}
                        </button>
                      ))}
                    </div>
                 </div>
                 <div className="space-y-1">
                    <span className="text-[9px] text-slate-500 font-bold uppercase">Escala: {Math.round((activeBubble.scale || 1) * 100)}%</span>
                    <input 
                      type="range" min="0.5" max="2" step="0.05"
                      value={activeBubble.scale || 1}
                      onMouseDown={(e) => e.stopPropagation()}
                      onInput={(e) => onBubbleUpdate && onBubbleUpdate({ ...activeBubble, scale: parseFloat((e.target as HTMLInputElement).value) })}
                      className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none accent-indigo-500"
                    />
                 </div>
              </div>
           )}

           <div className="flex gap-2">
              <button 
                onClick={() => onBubbleUpdate && onBubbleUpdate({ ...activeBubble, fontWeight: activeBubble.fontWeight === 'bold' ? 'normal' : 'bold' })}
                className={`flex-1 py-1.5 rounded-lg border text-xs font-bold ${activeBubble.fontWeight === 'bold' ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
              >
                B
              </button>
              <button 
                onClick={() => onBubbleUpdate && onBubbleUpdate({ ...activeBubble, fontStyle: activeBubble.fontStyle === 'italic' ? 'normal' : 'italic' })}
                className={`flex-1 py-1.5 rounded-lg border text-xs italic font-serif ${activeBubble.fontStyle === 'italic' ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
              >
                I
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default MangaViewer;
